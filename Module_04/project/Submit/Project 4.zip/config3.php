<?php
$dbhost = 'localhost';
$dbuser = 'imad97';
$dbpass = 'Emad5582866$';
$dbname = 'pizza';
 ?>
